document.addEventListener("DOMContentLoaded", function () {
  const accordionData = [
    { collapseId: "collapseOne2", accordionImgClass: "accordionimg1" },
    { collapseId: "collapseTwo2", accordionImgClass: "accordionimg2" },
    { collapseId: "collapseThree2", accordionImgClass: "accordionimg3" },
    { collapseId: "collapseFour2", accordionImgClass: "accordionimg4" },
    { collapseId: "collapseFive2", accordionImgClass: "accordionimg5" },
    { collapseId: "collapseSix2", accordionImgClass: "accordionimg6" },
    { collapseId: "collapseSeven2", accordionImgClass: "accordionimg7" },
    { collapseId: "collapseEight2", accordionImgClass: "accordionimg8" },
  ];

  // Function to show/hide accordionimg elements based on collapse state
  function showAccordionImgs() {
    accordionData.forEach((item) => {
      const collapseElement = document.getElementById(item.collapseId);
      const accordionImgElement = document.getElementsByClassName(
        item.accordionImgClass
      )[0];

      if (collapseElement && collapseElement.classList.contains("show")) {
        accordionImgElement.style.display = "block";
      } else {
        accordionImgElement.style.display = "none";
      }
    });
  }

  // Call showAccordionImgs initially
  showAccordionImgs();

  // Create a MutationObserver to watch for changes in the DOM
  const observer = new MutationObserver(function (mutationsList) {
    mutationsList.forEach((mutation) => {
      // Check if the class 'show' was added or removed from any collapse element
      if (
        mutation.type === "attributes" &&
        mutation.attributeName === "class"
      ) {
        showAccordionImgs(); // Update accordionimg display based on the change
      }
    });
  });

  // Observe changes in attributes of the body or subtree
  observer.observe(document.body, { attributes: true, subtree: true });

  // Optionally, you can stop observing when needed (e.g., when the component is removed)
  // observer.disconnect();
});

// Form JS by Neeraj

document.addEventListener("DOMContentLoaded", function () {
  // Target form elements
  var formElements = document.querySelectorAll(
    '.sk-form input[type="text"], .sk-form input[type="email"], .sk-form input[type="number"], .sk-form select, .sk-form textarea'
  );

  // Loop through each form element
  formElements.forEach(function (element) {
    // Apply initial custom styles
    element.style.border = "none"; // Remove default border
    element.style.borderBottom = "1px solid white"; // Apply bottom border
    element.style.backgroundColor = "transparent"; // Remove background color
    element.style.color = "white"; // Set text color
    element.style.outline = "none"; // Remove outline

    // Add focus event listener
    element.addEventListener("focus", function () {
      // Remove border color on focus
      element.style.borderBottomColor = "white"; // Set border bottom color to white on focus
    });

    // Add blur event listener
    element.addEventListener("blur", function () {
      // Restore border color on blur
      element.style.borderBottomColor = "white";
    });
  });

  // Hide .sk-form-header and .sk-logo-image
  var formHeader = document.querySelector(".sk-form-header");
  if (formHeader) {
    formHeader.style.display = "none";
  }

  var logoImage = document.querySelector(".sk-logo-image");
  if (logoImage) {
    logoImage.style.display = "none";
  }

  // Target form labels
  var formLabels = document.querySelectorAll(".sk-form label");

  // Apply custom styles to labels
  formLabels.forEach(function (label) {
    label.style.color = "white"; // Set label color
    // Add any additional label styles
  });

  // Target the button element
  var button = document.querySelector(".sk-form button");

  // Apply CSS styles to the button
  button.style.display = "block";
  button.style.width = "150px";
  button.style.padding = "18px 32px";
  button.style.borderRadius = "67px";

  // Add focus event listener to the button
  button.addEventListener("focus", function () {
    // Change background and border color on focus
    button.style.backgroundColor = "#F7D23B";
    button.style.borderColor = "#F7D23B";
  });

  // Add blur event listener to the button
  button.addEventListener("blur", function () {
    // Restore background and border color on blur
    button.style.backgroundColor = "#F7D23B";
    button.style.borderColor = "#F7D23B";
  });
});

document.addEventListener("DOMContentLoaded", function () {
  const elements = document.getElementsByClassName("l-capture-content");
  Array.from(elements).forEach(function (element) {
    element.innerHTML = element.innerHTML.replace(/&nbsp;/g, " ");
  });
});



// click and scroll to h3 
document.addEventListener("DOMContentLoaded", function () {
  // Select all list items
  var listItems = document.querySelectorAll(".l-capture-content ul li");

  // Iterate over each list item
  listItems.forEach(function (listItem) {
    // Add click event listener to each list item
    listItem.addEventListener("click", function () {
      // Get the text content of the clicked list item
      var listItemText = this.textContent.trim();

      // Iterate over each h3 heading
      var headings = document.querySelectorAll(".article-template__content h3");
      headings.forEach(function (heading) {
        // Compare the text content of the heading with the clicked list item
        if (heading.textContent.trim() === listItemText) {
          // Get the position of the heading
          var headingPosition = heading.getBoundingClientRect().top + window.scrollY;
          // Calculate the offset position
          var offsetPosition = headingPosition - 100;

          // Scroll to the offset position smoothly
          window.scrollTo({
            top: offsetPosition,
            behavior: "smooth"
          });
        }
      });
    });
  });
});


  document.addEventListener('DOMContentLoaded', function () {
            const dots = document.querySelectorAll('.custom-dot');

            dots.forEach(dot => {
                dot.addEventListener('click', function () {
                    dots.forEach(d => d.classList.remove('active')); // Remove active class from all dots
                    this.classList.add('active'); // Add active class to the clicked dot
                });
            });
        });


  (function() {
    // Wait for the DOM to fully load
    document.addEventListener("DOMContentLoaded", function() {
      console.log('JS Loaded!');

      // Get the current page's path (excluding the domain)
      var currentPath = window.location.pathname;
      console.log('Current Path:', currentPath);

      // Get all the anchor tags with the class 'makeActive'
      var links = document.querySelectorAll('.makeActive');

      // Loop through all anchor tags
      links.forEach(function(link) {
        // Extract the path part of each link's href
        var linkPath = new URL(link.href).pathname;
        console.log('Checking link path:', linkPath);

        // Default condition: Check if the current URL matches the link path
        if (currentPath === linkPath) {
          console.log('Exact match found:', linkPath);
          link.classList.add('active');
        }

        // Specific condition for "Oral Care" to match when the current URL contains "oral-health"
        if (link.innerText.trim() === "Oral Care" && currentPath.includes('oral-care')) {
          console.log('Specific match found for Oral Care with URL oral-health');
          link.classList.add('active');
        }
      });
      
      // Add click event listener to all links to handle active class on click
      links.forEach(function(link) {
        link.addEventListener('click', function() {
          // Remove active class from all links
          links.forEach(function(l) {
            l.classList.remove('active');
          });

          // Add active class to the clicked link
          this.classList.add('active');
        });
      });
    });
  })();











if (window.location.href === "https://kaesteo.com/collections/oral-care") {
  const productApplicator = document.querySelector("#product__applicator");
  if (productApplicator) {
    productApplicator.style.display = "none";
  }
}




if (window.location.href === "https://kaesteo.com/collections/serums") {
  const productOral = document.querySelector("#product__oral");
  if (productOral) {
    productOral.style.display = "none";
  }
}









